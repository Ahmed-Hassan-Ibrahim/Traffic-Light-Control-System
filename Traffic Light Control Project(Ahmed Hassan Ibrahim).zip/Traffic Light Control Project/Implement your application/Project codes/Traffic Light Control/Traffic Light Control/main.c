/*
 * Traffic Light Control.c
 *
 * Created: 9/12/2022 12:07:02 PM
 * Author : dinoa
 */ 

#include "Application/application.h"

int main(void)
{
    APP_init();
	APP_start();
}

