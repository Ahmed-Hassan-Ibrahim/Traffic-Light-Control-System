/*
 * types.h
 *
 * Created: 9/12/2022 4:29:01 PM
 *  Author: dinoa
 */ 


#ifndef TYPES_H_
#define TYPES_H_

typedef unsigned char uint8_t;

#endif /* TYPES_H_ */